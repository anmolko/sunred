

<?php $__env->startSection('title'); ?> FAQ <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
           
	.corpkit-content > .corpkit-content-inner {
		padding-top: 0;
		padding-bottom: 0;
	}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="corpkit-content-wrapper">
	<div class="corpkit-content corpkit-page">
		<header id="page-title" class="page-title-wrap">
		<div class="page-title-wrap-inner" data-property="no-video">
			<span class="page-title-overlay"></span>
			<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="page-title-inner">
					<div class="pull-left">
					<h1 class="page-title">Faq</h1>
					<div id="breadcrumb" class="breadcrumb">
						<a href="/">Home</a>
						<span class="current">Faq</span>
					</div>
					</div>
				</div>
				</div>
			</div>
			</div>
		</div>
		<!-- .page-title-wrap-inner -->
		</header>
		<div class="corpkit-content-inner">
		<div class="container">
			<div class="row">
			<div class="col-md-12">
				<div id="primary" class="content-area clearfix">
				<div
					id="page-10922"
					class="post-10922 page type-page status-publish hentry"
				>
					<div
					data-elementor-type="wp-page"
					data-elementor-id="10922"
					class="elementor elementor-10922"
					>
					<section
						data-cea-float='[{"float_title":"Floating Image","float_img":"<?php echo e(asset("assets/frontend/wp-content/uploads/sites/45/2021/08/icon-5.png")); ?>","float_left":"0","float_top":"50","float_distance":"","float_animation":"2","float_mouse":"0","float_width":"50px"}]'
						class="elementor-section elementor-top-section elementor-element elementor-element-ba6a5da elementor-section-stretched elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default"
						data-id="ba6a5da"
						data-element_type="section"
						data-settings='{"stretch_section":"section-stretched","background_background":"classic"}'
					>
						<div class="elementor-background-overlay"></div>
						<div
						class="elementor-container elementor-column-gap-extended"
						>
						<div
							class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-986c6b4"
							data-id="986c6b4"
							data-element_type="column"
							data-settings='{"background_background":"classic"}'
						>
							<div
							class="elementor-widget-wrap elementor-element-populated"
							>
							<div class="elementor-background-overlay"></div>
							<div
								class="elementor-element elementor-element-bcdac93 cea-align-left elementor-widget elementor-widget-ceasectiontitle"
								data-id="bcdac93"
								data-element_type="widget"
								data-widget_type="ceasectiontitle.default"
							>
								<div class="elementor-widget-container">
								<div class="section-title-wrapper">
									<div class="title-wrap">
									<h6 class="sub-title">
									<?php echo e(ucwords(@$accordian2_elements[0]->heading)); ?>

									</h6>
									<h2 class="section-title">
									<?php echo e(ucwords(@$accordian2_elements[0]->subheading)); ?>


									</h2>
									</div>
									<!-- .title-wrap -->
									<div class="section-description">
									<p class="section-content">
									<?php echo e(@$accordian2_elements[0]->description); ?>

									</p>
										<?php if(@$accordian2_elements[0]->button_link): ?>
											<div class="cea-button-wrapper">
												<a
												href="<?php echo e(@$accordian2_elements[0]->button_link); ?>"
												class="cea-button-link elementor-button cea-button elementor-size-sm"
												>
												<span
													class="cea-button-content-wrapper"
												>
													<span
													class="cea-button-icon cea-align-icon-"
													>
													</span>
													<span class="cea-button-text"
													><?php echo e(ucwords(@$accordian2_elements[0]->button)); ?></span
													>
												</span>
												</a>
											</div>
										<?php endif; ?>
									</div>
									<!-- .section-description -->
								</div>
								<!-- .section-title-wrapper -->
								</div>
							</div>
							</div>
						</div>
						<div
							class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-0b4c1e1"
							data-id="0b4c1e1"
							data-element_type="column"
						>
							<div
							class="elementor-widget-wrap elementor-element-populated"
							>
							<div
								class="elementor-element elementor-element-5fac64a elementor-widget elementor-widget-ceaaccordion"
								data-id="5fac64a"
								data-element_type="widget"
								data-widget_type="ceaaccordion.default"
							>
								<div
								class="elementor-widget-container cea-accordion-elementor-widget"
								data-toggle=""
								>
								<div
									class="cea-accordions"
									id="cea-accordion-1">
									<?php for($i = 1; $i <=$list_2; $i++): ?>
									<div class="card cea-accordion">
										<div class="card-header cea-accordion-header" >
											<a
											class="nav-item nav-link <?php if($i == '1'): ?> active <?php endif; ?>"
											href="#cea-accordion-1-<?php echo e($i); ?>"
											><span
												class="elementor-accordion-icon elementor-accordion-icon-right"
												aria-hidden="true"
												><span
												class="cea-accordion-icon-closed"
												><i
													class="ti ti-arrow-circle-down"
												></i></span
												><span
												class="cea-accordion-icon-opened"
												><i
													class="ti ti-arrow-circle-up"
												></i></span></span
											><?php echo e(@$accordian2_elements[$i-1]->list_header); ?></a
											>
										</div>
										<!-- .card-header -->
										<div class="cea-accordion-content <?php if($i == '1'): ?> active <?php endif; ?>"
											id="cea-accordion-1-<?php echo e($i); ?>" >
											<div class="card-body">
												<div class="cea-accordion-pane">
												<?php echo @$accordian2_elements[$i-1]->list_description; ?>

												</div>
											</div>
										<!-- .card-body -->
										</div>
										<!-- .cea-accordion-content -->
									</div>
									<?php endfor; ?>
							
								</div>
								</div>
							</div>
							</div>
						</div>
						</div>
					</section>
					</div>
				</div>
				<!-- #post-## -->
				</div>
				<!-- #primary -->
			</div>
			<!-- main col -->
			</div>
			<!-- row -->
		</div>
		<!-- .container -->
		</div>
		<!-- .corpkit-content-inner -->
	</div>
<!-- .corpkit-content -->
</div>


		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\sunred\resources\views/frontend/pages/faq.blade.php ENDPATH**/ ?>
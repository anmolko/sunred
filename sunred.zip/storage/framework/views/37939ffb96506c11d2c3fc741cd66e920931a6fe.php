<aside class="widget-area left-widget-area">
    <div id="nav_menu-3" class="widget widget_nav_menu">
        <h3 class="widget-title">All Slider Lists</h3>
        <div class="menu-services-sidebar-container">
            <?php if(!empty($slider_lists)): ?>

            <ul id="menu-services-sidebar" class="menu">
                <?php $__currentLoopData = @$slider_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li id="menu-item-9676" class="menu-item menu-item-type-post_type menu-item-object-berater-services <?php if(Request::url() === url('/slider-list/'.$slider->subheading)): ?> current-menu-item <?php endif; ?> menu-item-9676"><a href="<?php echo e(url('/slider-list/'.$slider->subheading)); ?>"  <?php if(Request::url() === url('/slider-list/'.$slider->subheading)): ?> aria-current="page" <?php endif; ?> ><?php echo e(ucwords(@$slider->list_header)); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
    
</aside><?php /**PATH D:\project\sunred\resources\views/frontend/pages/sliderlist/sidebar.blade.php ENDPATH**/ ?>
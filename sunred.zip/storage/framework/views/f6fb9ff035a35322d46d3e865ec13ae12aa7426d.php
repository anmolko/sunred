
<?php $__env->startSection('title'); ?> Edit a Page <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

    <style>
        /*for image*/
        .avatar-upload{
            max-width: 505px!important;
        }

        .upper-case{
            text-transform: capitalize;
        }

        .current-img{
            border: 6px solid #f3f3f3;
            border-radius: 10px;
        }

        #blog-img{
            border: 6px solid #f3f3f3;
            border-radius: 10px;
        }
        /*end for image*/

        .nopad {
            padding-left: 0 !important;
            padding-right: 0 !important;
        }
        /*image gallery*/
        .image-checkbox {
            cursor: pointer;
            box-sizing: border-box;
            -moz-box-sizing: border-box;
            -webkit-box-sizing: border-box;
            border: 4px solid transparent;
            margin-bottom: 0;
            outline: 0;
            position:relative;
        }
        .image-checkbox input[type="checkbox"] {
            display: none;
        }

        .hidden{
            display: none;
        }

        .image-checkbox-checked {
            border-color: #4783B0;
        }
        .image-checkbox .ri {
            position: absolute;
            color: #4A79A3;
            background-color: #fff;
            /* padding: 5px; */
            top: -4px;
            right: -3px;
            border: 4px solid #4A79A3;
            font-size: 18px;
            font-weight: 700;

        }
        .image-checkbox-checked .ri {
            display: block !important;
        }

        /*end of checklist design*/

        /*for sortable*/
        #sortable { list-style-type: none; margin: 0; padding: 0; }
        #sortable li {cursor:move; margin-top: 10px;  transition: -webkit-transform ease-out 0.3s;
            -webkit-transform-origin: 50% 50%; }
        body.dragging, body.dragging * {cursor: move !important; }
        .dragged {position: absolute;z-index: 1; transform: perspective(800px) translateZ(20px);}
        #sortable li span { position: absolute; }
        #sortable li.fixed{cursor:default; color:#959595; opacity:0.5;}

        .div-center{
            margin: auto;width: 70%;
        }


        /*end of sortable*/

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>




    <div class="page-content">
        <div class="container-fluid">

            <?php echo Form::open(['method'=>'PUT','id'=>'pageedit-form','url'=>route('pages.update', $page->id),'class'=>'needs-validation','novalidate'=>'','enctype'=>'multipart/form-data']); ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="card ctm-border-radius shadow-sm flex-fill">
                        <div class="card-header">
                            <h4 class="card-title mb-0">
                                General Details
                            </h4>
                        </div>
                        <div class="card-body">
                            <div class="form-group mb-3">
                                <label>Page Name <span class="text-muted text-danger">*</span></label>
                                <input type="text" class="form-control" name="name" id="name" value="<?php echo e($page->name); ?>" required>
                                <div class="invalid-feedback">
                                    Please enter the page Name.
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Slug <span class="text-muted text-danger">*</span></label>
                                <input type="text" class="form-control" name="slug" id="slug" value="<?php echo e($page->slug); ?>" required>
                                <div class="invalid-feedback">
                                    Please enter the Page Slug.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card ctm-border-radius shadow-sm grow">
                        <div class="card-header">
                            <h4 class="card-title doc d-inline-block mb-0">Choose the Section for Pages </h4>
                            <br/>
                            <span class="ctm-text-sm">* Select the sections to use in the page by clicking on the section images below.</span>
                        </div>
                        <div class="card-body doc-boby">
                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Basic Section</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="image-checkbox <?php echo e((in_array('basic_section', $sections) ? "image-checkbox-checked":"")); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/basic_section.png')); ?>" />
                                                <input type="checkbox" name="section[]" value="basic_section" id="basic_section.png" <?php echo e((in_array('basic_section', $sections) ? "checked":"")); ?> />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Call to Action</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="image-checkbox <?php echo e((in_array('call_to_action_1', $sections) ? "image-checkbox-checked":"")); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/calltoaction.png')); ?>" />
                                                <input type="checkbox" name="section[]" value="call_to_action_1" id="calltoaction.png" <?php echo e((in_array('call_to_action_1', $sections) ? "checked":"")); ?> />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Background Image Section</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class='image-checkbox <?php echo e((in_array('background_image_section', $sections) ? "image-checkbox-checked":"")); ?>'>
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/background_image_section.png')); ?>" width="90%"/>
                                                <input type="checkbox" name="section[]" value="background_image_section" id="background_image_section.png" <?php echo e((in_array('background_image_section', $sections) ? "checked":"")); ?>  />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Mission, Vision & Values</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="image-checkbox <?php echo e((in_array('flash_cards', $sections) ? "image-checkbox-checked":"")); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/mission_vision.png')); ?>" />
                                                <input type="checkbox" name="section[]" value="flash_cards" id="mission_vision.png" <?php echo e((in_array('flash_cards', $sections) ? "checked":"")); ?> />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Simple Header & Description</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="image-checkbox <?php echo e((in_array('simple_header_and_description', $sections) ? "image-checkbox-checked":"")); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/simple_header_descp.png')); ?>" />
                                                <input type="checkbox" name="section[]" id="simple_header_descp.png" value="simple_header_and_description" <?php echo e((in_array('simple_header_and_description', $sections) ? "checked":"")); ?> />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Map and Description</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="image-checkbox <?php echo e((in_array('map_and_description', $sections) ? "image-checkbox-checked":"")); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/map_and_description.png')); ?>" />
                                                <input type="checkbox" name="section[]" id="map_and_description.png" value="map_and_description" <?php echo e((in_array('map_and_description', $sections) ? "checked":"")); ?> />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Simple Accordion Tab </h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <input type="hidden" class="form-control" name="list_number_2"  id="list_number_2" value="<?php echo e($list2); ?>" required>
                                            <input type="hidden" name="list_2_id" value="<?php echo e($list2_id); ?>">
                                        </div>
                                        <div class="col-md-12">
                                            <label class="image-checkbox <?php echo e((in_array('accordion_section_2', $sections) ? "image-checkbox-checked":"")); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/simple_accordian_tab2.png')); ?>" />
                                                <input type="checkbox" name="section[]" id="simple_accordian_tab2.png" value="accordion_section_2" <?php echo e((in_array('accordion_section_2', $sections) ? "checked":"")); ?> />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                            <span class="ctm-text-sm text-warning">* Can be used for multiple Q & A section such as FAQs.</span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Gallery Section 1 </h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="image-checkbox <?php echo e((in_array('gallery_section', $sections) ? "image-checkbox-checked":"")); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/gallery_section.png')); ?>" />
                                                <input type="checkbox" name="section[]" value="gallery_section" id="gallery_section.png" <?php echo e((in_array('gallery_section', $sections) ? "checked":"")); ?>  />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Gallery Section 2 </h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="image-checkbox <?php echo e((in_array('gallery_section_2', $sections) ? "image-checkbox-checked":"")); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/gallery_section_2.png')); ?>" />
                                                <input type="checkbox" name="section[]" value="gallery_section_2" id="gallery_section_2.png" <?php echo e((in_array('gallery_section_2', $sections) ? "checked":"")); ?>  />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Slider Lists</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <div class="form-group">
                                                <label>Number of Slider List <span class="text-muted text-danger">*</span></label>
                                                <input type="number" min="3" class="form-control" name="list_number_3" id="list_number_3" value="<?php echo e($list3); ?>">
                                                <input type="hidden" name="list_3_id" value="<?php echo e($list3_id); ?>">
                                                <div class="invalid-feedback">
                                                    Please enter the list number.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="image-checkbox <?php echo e((in_array('slider_list', $sections) ? "image-checkbox-checked":"")); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/list_option_1.png')); ?>" />
                                                <input type="checkbox" name="section[]" id="list_option_1.png" value="slider_list" <?php echo e((in_array('slider_list', $sections) ? "checked":"")); ?> />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                            <span class="ctm-text-sm text-warning">* using this element will create a inner page to display individual list data. Use only when big informations are needed to be showcased</span>

                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="card shadow-none">
                                <div class="card-header">
                                    <h5 class="card-title text-primary mb-0">Box description</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Select number of box description <span class="text-muted text-danger">*</span></label>
                                                <select class="form-control select" name="list_number_3_process_sel" id="list_number_3_process_sel">
                                                    <option <?php echo e(($process_number == null) ? "disabled selected":"disabled"); ?>>Select Number of List</option>
                                                    <option value="3" <?php echo e(($process_number =="3") ? "selected":""); ?>>Three</option>
                                                    <option value="6" <?php echo e(($process_number =="6") ? "selected":""); ?>>Six</option>
                                                </select>
                                                <input type="hidden" name="process_sel_id" value="<?php echo e($process_id); ?>">
                                                <span class="ctm-text-sm text-warning">* Please choose the list numbers in odd format such as 3 or 6.</span>
                                                <div class="invalid-feedback">
                                                    Please enter the list number.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="image-checkbox <?php echo e((in_array('small_box_description', $sections) ? "image-checkbox-checked":"")); ?>">
                                                <img class="img-responsive" src="<?php echo e(asset('assets/backend/img/page_sections/small_box_description.png')); ?>" />
                                                <input type="checkbox" name="section[]" id="small_box_description.png" value="small_box_description" <?php echo e((in_array('small_box_description', $sections) ? "checked":"")); ?> />
                                                <i class="ri ri-check-line hidden"></i>
                                            </label>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="text-end mb-4">
                        <input type="hidden" name="status" id="status" value="<?php echo e($page->status); ?>"/>

                        <button type="button" class="btn btn-success w-sm" name="btnstatus" id="status1" value="active">Active</button>
                        <button type="button" class="btn btn-warning w-sm" name="btnstatus" id="status2" value="deactive">De-Active</button>
                    </div>
                </div>
            </div>


            <?php echo Form::close(); ?>


        </div>
    </div>

    <div class="modal fade" id="editStructure" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 modal-lg">
                <div class="modal-header p-3 ps-4 bg-soft-success">
                    <h5 class="modal-title" id="myModalLabel">Page Structure</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <h4 class="modal-title mb-3">Edit Your Page Sections Structure By Dragging Them</h4>

                    <div id="items-container">
                        <ul class="ui-sortable" id="sortable">
                            
                        </ul>
                    </div>

                    <div class="text-center mb-3 mt-4">
                        <button id="submiteditpagedata" class="btn btn-success w-sm">Update Page</button>
                    </div>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/backend/js/jquery-sortable.js')); ?>"></script>
    <script type="text/javascript">
        var section_list = new Array();
        var section_names = new Array();
        <?php foreach($ordered_sections as $key=>$value){ ?>
        section_list.push({
            name: '<?php echo $key; ?>',
            image: '<?php echo $value; ?>'
        });
        section_names.push('<?php echo $key; ?>');
        <?php } ?>


        //settings for sortable JS
        $("#sortable").sortable({
            onDrop: function ($item, container, _super) {
                //for animation
                var $clonedItem = $('<li/>').css({height: 0});
                $item.before($clonedItem);
                $clonedItem.animate({'height': $item.height()});

                $item.animate($clonedItem.position(), function  () {
                    $clonedItem.detach();
                    _super($item, container);
                });
            },
            onDragStart: function ($item, container, _super) {
                var offset = $item.offset(),
                    pointer = container.rootGroup.pointer;

                adjustment = {
                    left: pointer.left - offset.left,
                    top: pointer.top - offset.top
                };

                _super($item, container);
            },
            //for animation
            onDrag: function ($item, position) {
                $item.css({
                    left: position.left - adjustment.left,
                    top: position.top - adjustment.top
                });
            }
        });
        //settings for sortable JS
        $("#name").keyup(function(){
            var Text = $(this).val();
            Text = Text.toLowerCase();
            var regExp = /\s+/g;
            Text = Text.replace(regExp,'-');
            $("#slug").val(Text);
        });

        // $(document).ready(function () {
        //
        //
        // });

        // image gallery
        // init the state from the input
        $(".image-checkbox").each(function () {
            if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
                $(this).addClass('image-checkbox-checked');
            }

        });

        // sync the state to the input
        $(".image-checkbox").on("click", function (e) {
            $(this).toggleClass('image-checkbox-checked');
            var $checkbox = $(this).find('input[type="checkbox"]');
            $checkbox.prop("checked",!$checkbox.prop("checked"))

            e.preventDefault();
        });

        $('#status1, #status2').click(function(event){
            event.preventDefault();
            var form = $('#pageedit-form')[0];
            if (!form.reportValidity()) {return false;}
            var status         = $(this).val();
            $('#status').val(status);
            var namelist = new Array();
            var newaddition = new Array();
            $("input:checkbox:checked").each(function() {
                //creating the array of section names only to check with db section names
                namelist.push($(this).val());
                //comparing all the selected sections from this edit page with original section list of DB
                //creating array of newly added sections only
                if($.inArray($(this).val(), section_names) == -1){
                    newaddition.push({
                        name: $(this).val(),
                        image:  $(this).attr("id")
                    });
                }
            });
            $("#editStructure").modal("toggle");//activate the modal
            $('#sortable').empty();//empty the sortable div data to avoid repetition
            let i = 1; //counter for the original section list
            section_list.forEach(function(item) {
                var name = item.name;
                var newname = name.replace(new RegExp('_', 'g')," ");
                //adding the original sections that were created with the page in the list first
                var dbsection = '<li class="'+item.name+'" id="' + i + '">' +
                    '<div class="col-md-10 div-center">' +
                    '<label class="upper-case">' + newname + '</label>' +
                    '<img width="90%" src="/assets/backend/img/page_sections/' + item.image + '"/>' +
                    '</div>' +
                    '</li> ';
                $('#sortable').append(dbsection);
                i++;

                if($.inArray(item.name, namelist) == -1){
                    $('.'+item.name+'').remove();
                    //checking in the arrary if any of the original section is removed and if yes,
                    //removing them from the UL list as well
                }
            });

            //starting the counter where the first counter for already existing sections ended
            let j = i;
            //looping through the new sections which do not exist in the original section list from database
            newaddition.forEach(function(item) {
                var name = item.name;
                var newname = name.replace(new RegExp('_', 'g')," ");
                var replacements = '<li class="'+item.name+'" id="' + j + '">' +
                    '<div class="col-md-10 div-center">' +
                    '<label class="upper-case">' + newname + '</label>' +
                    '<img width="90%" src="/assets/backend/img/page_sections/' + item.image + '"/>' +
                    '</div>' +
                    '</li> ';
                $('#sortable').append(replacements);
                j++;
                //populate the div by appending the image and section name from loop
            });
        });

        //submit the data from previous form and the values of sortable field on button click
        $('#submiteditpagedata').click(function(){
            var form       = $('#pageedit-form')[0];
            var form_data  = new FormData(form); //Creates new FormData object
            var section_name        = $('#sortable li').map(function(i) {
                return $(this).attr('class'); }).get();
            //get the names of the section present as class in sortable UL's li

            for (var i = 0; i < section_name.length; i++) {
                form_data.append('position[]', i+1);//send the position array in terms of number of li present in sortable UL
                form_data.append('sorted_sections[]', section_name[i]);//send the section names listed in sortable UL
            }
            var post_url       = $('#pageedit-form').attr("action"); //get form action url
            var request_method = $('#pageedit-form').attr("method"); //get form GET/POST method

            $.ajax({
                url : post_url,
                type: request_method,
                data : form_data,
                contentType: false,
                cache: false,
                processData:false
            }).done(function(response){
                if(response.status=='warning'){
                    toastr.warning(response.message);
                }else{
                    //when the response is received, it will redirect to the dynamic route sent from controller
                    window.location.replace(response);
                }
            });
        });


    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\sunred\resources\views/backend/pages/edit.blade.php ENDPATH**/ ?>
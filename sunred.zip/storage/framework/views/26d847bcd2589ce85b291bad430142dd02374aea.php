<aside class="widget-area right-widget-area">
    <section id="search-1" class="widget widget_search">
        <form
        method="get"
        class="search-form"
        id="searchform" action="<?php echo e(route('searchBlog')); ?>"
        >
        <div class="input-group">
            <input
            class="form-control"
            id="s" name="s" type="text" placeholder="Enter Keyword" oninvalid="this.setCustomValidity('Type a keyword')" oninput="this.setCustomValidity('')" required
            />
            <span class="input-group-btn">
            <button class="btn btn-secondary" type="submit">
                <i class="ti-arrow-right"></i>
            </button>
            </span>
        </div>
        </form>
    </section>
    <section
        id="corpkit_latest_post_widget-3"
        class="widget corpkit_latest_post_widget"
    >
        <h3 class="widget-title">Latest Posts</h3>
        <div class="widg-content">
        <ul class="side-newsfeed">
        <?php if(!empty($latestPosts)): ?>
            <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
            <div class="side-item">
                <div class="side-image">
                <a
                    href="<?php echo e(route('blog.single',@$latest->slug)); ?>"
                    rel="bookmark"
                    ><img
                    width="80"
                    height="80"
                    src="<?php if(@$latest->image){?><?php echo e(asset('/images/blog/thumb/thumb_'.@$latest->image)); ?><?php }?>"
                    class="img-responsive wp-post-image"
                    alt=""
                    loading="lazy"
                 
                    sizes="(max-width: 80px) 100vw, 80px"
                /></a>
                </div>
                <div class="side-item-text">
                <a
                    class="themeh-color"
                    href="<?php echo e(route('blog.single',@$latest->slug)); ?>"><?php echo e(ucwords(@$latest->title)); ?></a
                >
                <div class="comments-wrap">
                    <div class="meta-left">
                    <span class=""><?php echo e(date('M j, Y',strtotime(@$latest->created_at))); ?></span>
                    </div>
                </div>
                </div>
            </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </ul>
        </div>
    </section>
    <section id="categories-2" class="widget widget_categories">
        <h3 class="widget-title">Categories</h3>
        <ul>
    
        <?php if(!empty($bcategories)): ?>
            <?php $__currentLoopData = @$bcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="cat-item cat-item-16"><a class="<?php if(Request::url() === url('/blog/categories/'.$bcategory->slug)): ?> active <?php endif; ?>"
                    href="<?php echo e(url('/blog/categories/'.$bcategory->slug)); ?>"><?php echo e(ucwords(@$bcategory->name)); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </ul>

        
    </section>
    
</aside><?php /**PATH D:\project\sunred\resources\views/frontend/pages/blogs/sidebar.blade.php ENDPATH**/ ?>
@include('backend.partials.header')
@include('backend.partials.sidebar')
@yield('content')
@include('backend.partials.footer')

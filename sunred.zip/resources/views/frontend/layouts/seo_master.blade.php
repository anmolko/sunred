@include('frontend.partials.seo_header')
@yield('content')
@include('frontend.partials.footer')
